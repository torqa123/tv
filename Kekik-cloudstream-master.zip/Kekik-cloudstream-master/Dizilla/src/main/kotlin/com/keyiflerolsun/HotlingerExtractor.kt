// ! Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

package com.keyiflerolsun

class Hotlinger : ContentX() {
    override var name    = "Hotlinger"
    override var mainUrl = "https://hotlinger.com"
}